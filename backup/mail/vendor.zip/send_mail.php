<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php'; 

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);



try {
    
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];
    $first_name = $_POST['firstname'];
    $last_name = $_POST['lastname'];
    $ip = $_POST['ip'];
    $budget = $_POST['budget'];
        
    //Server settings
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'mail.techversellc.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'info@techversellc.com';                     //SMTP username
    $mail->Password   = 'TjyH.z5R%?DQ';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('info@techversellc.com', 'Mailer');
    $mail->addAddress('info@techversellc.com');               //Name is optional
   

    
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Techverse Lead';
    $mail->Body    = '
                <ul>
                    <li><b>First Name</b>: '. $name .'</li>
                    <li><b>Last Name</b>: '. $name .'</li>
                    <li><b>Message</b>: '. $name .'</li>
                    <li><b>Email</b>: '. $name .'</li>
                    <li><b></b>: '. $name .'</li>
                    <li><b>Full Name</b>: '. $name .'</li>
                    <li><b>Full Name</b>: '. $name .'</li>
                </ul>
                
            ';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}